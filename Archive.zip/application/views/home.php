<?php $this->load->view('widget/head'); ?>
<?php $this->load->view('widget/navigation'); ?>
        <div class="container-fluid">
            <div class="row">
                <?php $this->load->view('widget/sidebar'); ?>
                <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                    <h1 class="page-header"><a href="/app"><img src="<?php echo base_url()."assets/"; ?>img/logo.png"></a></h1>
                    <div class="row placeholders">
                    <?php $this->load->view($page); ?>
                    </div>
                </div>
            </div>
        </div>
<?php $this->load->view('widget/foot'); ?>
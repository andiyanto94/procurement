<table width="100%" height="338" border="1">
  <tr align="center">
    <th width="32" height="23" valign="top" scope="col">NO </th>
    <th width="534" valign="top" scope="col">DESCRIPTION</th>
    <th width="283" valign="top" scope="col">QTY</th>
    <th width="286" valign="top" scope="col">REMARK</th>
  </tr>
  <tr>
    <td height="230">1.</td>
    <td>BALDOR ELECTRIC MOTOR , EM704IT</td>
    <td>2 UNIT </td>
    <td>COMPLETE</td>
  </tr>
  <tr>
    <td height="75" colspan="2">NOTE : Completed with Certificate Of Manufacture</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
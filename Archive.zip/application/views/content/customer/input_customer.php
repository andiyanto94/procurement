<h2 class="text-left">Input Customer</h2>
<hr>
<div class="container col-sm-12 text-left">
    <div class="col-sm-12">
        
            <form>
                <h5 class="sub-header">Name</h5>
                <div class="form-group col-sm-6">
                    <label for="email">Title</label>
                    <select class="form-control">
                        <option>1</option>
                        <option>1</option>
                        <option>1</option>
                    </select>
                </div>
                <div class="form-group col-sm-6">
                    <label for="name">Name </label>
                    <input type="text" class="form-control" id="name">
                </div>
                <h5 class="sub-header">Street Address</h5>
                <div class="form-group col-sm-6">
                    <label for="house">Street/House No.</label>
                    <input type="text" class="form-control" id="house">
                </div>
                <div class="form-group col-sm-6">
                    <label for="city">City</label>
                    <input type="text" class="form-control" id="city">
                </div>
                <div class="form-group col-sm-6">
                    <label for="postal">Postal Code</label>
                    <input type="text" class="form-control" id="postal">
                </div>
                <div class="form-group col-sm-6">
                    <label for="country">Country</label>
                    <input type="text" class="form-control" id="country">
                </div>
                <div class="form-group col-sm-6">
                    <label for="region">Region</label>
                    <input type="text" class="form-control" id="region">
                </div>
                <div class="form-group col-sm-6">
                    <label for="transportation">Transportation Zone</label>
                    <input type="text" class="form-control" id="transportation">
                </div>
                <br>
                <h5 class="sub-header">PO Box Address</h5>
                <div class="form-group col-sm-6">
                    <label for="box">PO Box</label>
                    <input type="text" class="form-control" id="box">
                </div>
                <div class="form-group col-sm-6">
                    <label for="city">Postal Code</label>
                    <input type="text" class="form-control" id="city">
                </div>
                <h5 class="sub-header">Communication</h5>
                <div class="form-group col-sm-6">
                    <label for="lang">Language</label>
                    <input type="text" class="form-control" id="lang">
                </div>
                <div class="form-group col-sm-6">
                    <label for="tlp">Telephone</label>
                    <input type="text" class="form-control" id="tlp">
                </div>
                <div class="form-group col-sm-6">
                    <label for="fax">Fax</label>
                    <input type="text" class="form-control" id="fax">
                </div>
                <div class="form-group col-sm-6">
                    <label for="email">E-Mail</label>
                    <input type="email" class="form-control" id="email">
                </div>
                <div class="form-group col-sm-6">
                    <label for="line">Data Line</label>
                    <input type="text" class="form-control" id="line">
                </div>
                
            </form>
        <hr/>
                 <div class="col-sm-offset-8 col-sm-12">
                        <button type="button" class="btn btn-default">Cancel</button>
                        <button type="button" class="btn btn-success">Success</button>
                    </div>   
    </div>
    
</div>
  <h2 class="text-center">Input New PO</h2><hr>
  <form action="?home=registrasi&&register=1" class="col-sm-10 form-horizontal" method="post">
    <div class="form-group">
      <label class="control-label col-sm-4" for="no">PO Number</label>
      <div class="col-sm-6">
      <input type="text" name="full_name" id="no" class="form-control" value="" placeholder="Nama Lengkap">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="email">Email :</label>
      <div class="col-sm-6">
      <input type="text" name="email" id="email" class="form-control" value="" placeholder="Masukkan Email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="email">Telepon :</label>
      <div class="col-sm-6">
      <input type="text" name="tlp" id="tlp" class="form-control" value="" placeholder="+62">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="gender">Jenis Kelamin :</label>
      <div class="col-sm-6">
          <label class="radio-inline"><input type="radio" name="gender" id="gender" value="Laki-laki"> Laki-laki</label>
          <label class="radio-inline"><input type="radio" name="gender" id="gender" value="Perempuan"> Perempuan</label>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="alamat">Alamat Lengkap :</label>
      <div class="col-sm-6">
      <input type="text" name="alamat" id="alamat" class="form-control" value="" placeholder="Pastikan alamat benar">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="pekerjaan">Pekerjaan :</label>
      <div class="col-sm-6">
      <input type="text" name="pekerjaan" id="pekerjaan" class="form-control" value="" placeholder="Pekerjaan saat ini">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="password">Password :</label>
      <div class="col-sm-6">
      <input type="password" name="password" id="password" class="form-control" value="" placeholder="Password">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="confirm">Konfirmasi Password :</label>
      <div class="col-sm-6">
      <input type="password" name="confirm" id="confirm" class="form-control" value="" placeholder="Konfirmasi Password">
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-4 col-sm-4">
        <button type="submit" class="btn btn-primary">Daftar</button> Atau sudah menjadi donator? <a href="?home=login&&login=1">Login!</a>
      </div>
    </div>
  </form>
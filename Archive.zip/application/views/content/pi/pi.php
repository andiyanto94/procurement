<h3 class="text-left">PURCHASE INSTRUCTION FORM</h3>
<hr>
 <form class="form-inline pull-left">
  <div class="form-group">
    <label for="pi">PI No. : </label>
    <input type="text" class="form-control" id="pi">
  </div>
  <div class="form-group">
    <label for="date">Date : </label>
    <input type="text" class="form-control" id="date">
  </div>
</form>
<br><hr>
<div class="container col-sm-12 text-left">
    <div class="col-sm-12">
        <h3 class="sub-header text-left">BUSINESS UNIT :</h3>
        <form>
            <div class="form-group col-sm-6">
                <label for="email">Unit Name </label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Quotation No. </label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Customer PO No. </label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Project ID </label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Customer </label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Sales Person ID </label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Acknowledgement Date </label>
                <input type="text" class="form-control" id="email">
            </div>
        </form>
    </div>
    <br>
    <br>
    
    <div class="col-sm-12" style="border-top: 2px #ccc solid;">
        <br>
        <h3 class="sub-header text-left">Vendor :</h3>
        <form>
            <div class="form-group col-sm-12">
                <label for="email">Name</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Address</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Vendor ID</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">PIC</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Telephone</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Fax</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Email</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Currency</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Del Time</label>
                <input type="text" class="form-control" id="email">
            </div>
            <div class="form-group col-sm-6">
                <label for="email">Delivery Point</label>
                <input type="text" class="form-control" id="email">
            </div>
        </form>
    </div>
    
    
    <div class="col-sm-12" style="border-top: 2px #ccc solid;">
        <br>
        <h3 class="sub-header text-left">ORDER DETAIL :</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                  <tr>
                    <th>Description</th>
                    <th>QTY</th>
                    <th>Unit</th>
                    <th>Unit Price</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Baldor rrrr</td>
                    <td>2</td>
                    <td>Unit</td>
                    <td>$ 1.0000</td>
                  </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="col-sm-12" style="border-top: 2px #ccc solid;">
        <br>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr style="background: #000; color: #ccc;">
                        <th colspan="4" scope="row" style="border-right: 1px #ccc solid;">SHIPMENT DETAIL</th>
                        <th colspan="2" scope="row">DELIVERY DETAIL</th>
                  </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                        Shipment Method
                        </td>
                        <td>
                            : <select name="shipment">
                                <option>Air Freight</option>
                                <option>Darat</option>
                            </select>
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        Nos of Packages
                        </td>
                        <td>
                        
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        Customer Req. Delivery
                        </td>
                        <td>
                        
                        </td>
                    </tr>
                    <tr>
                        <td>
                        Shipment Dimension
                        </td>
                        <td>
                        :
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        Shipment Weight
                        </td>
                        <td>
                        : 113 Kg
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        Local Trucking
                        </td>
                        <td>
                            : <input type="radio" name="trucking"> Yes <br>
                            : <input type="radio" name="trucking"> No 
                        </td>
                    </tr>
                    <tr>
                        <td>
                        Origin Port
                        </td>
                        <td>
                        : <select name="shipment">
                                <option>USA</option>
                                <option>ID</option>
                            </select>
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        
                        </td>
                        <td>
                        
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        PIC
                        </td>
                        <td>
                        : Pa Octavianus
                        </td>
                    </tr>
                    <tr>
                        <td>
                        Recieved Point
                        </td>
                        <td>
                        :
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        
                        </td>
                        <td>
                        
                        </td>
                        <td style="border-left: 1px #000 solid;">
                        Telephon
                        </td>
                        <td>
                        : 0211111
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="col-sm-12" style="border-top: 2px #ccc solid;">
        <br>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr style="background: #000; color: #ccc;">
                        <th colspan="3" scope="row">SUPPORTING DOCUMENTS</th>
                  </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <input type="checkbox" name="document"> Customer PO Copy<br>
                            <input type="checkbox" name="document"> Bid Comparision Sheet<br>
                            <input type="checkbox" name="document"> PreCal Sheet
                        <td>
                            <input type="checkbox" name="document"> Final Vendor Quotatation Copy<br>
                            <input type="checkbox" name="document"> Vendor Bank Detail<br>
                            <input type="checkbox" name="document"> Email Conversation Copy
                        </td>
                        <td>
                            Other : ___________________________________________________
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="col-sm-12" style="border-top: 2px #ccc solid;">
        <h3>NOTE</h3>
        <textarea class="form-control" rows="5"></textarea>
    </div>
</div>
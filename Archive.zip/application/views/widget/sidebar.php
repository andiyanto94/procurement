<div class="col-sm-3 col-md-2 sidebar" style="background: #215c8c;">
    <ul class="nav nav-sidebar">
        <li class="active">
            <a data-toggle="collapse" href="#collapse1" style="color: #ffffff;">Data Master <span class="sr-only">(current)</span></a>
            <ul class="list-group panel-collapse collapse" id="collapse1">
                <li class="list-group-item"><a href="/app/home/material">Data Material</a></li>
                <li class="list-group-item"><a href="/app/home/customer">Data Customer</a></li>
                <li class="list-group-item"><a href="/app/home/vendor">Data Vendor</a></li>
            </ul>
        </li>
        <li>
            <a data-toggle="collapse" href="#customer" class="a-sidebar"><span class="glyphicon glyphicon-plus"></span>Customer</a>
            <ul class="list-group panel-collapse collapse" id="customer">
                <li class="list-group-item"><a href="/app/home/input_customer">New Customer</a></li>
                <li class="list-group-item"><a href="/app/home/customer">Data Customer</a></li>
            </ul>
        </li>
        <li>
            <a data-toggle="collapse" href="#pi"><span class="glyphicon glyphicon-file"></span> Purchase Order</a>
            <ul class="list-group panel-collapse collapse" id="pi">
                <li class="list-group-item"><a href="/app/home/input_po">New PO</a></li>
                <li class="list-group-item"><a href="/app/home/po">Data PO</a></li>
            </ul>
        </li>
        <li>
            <a data-toggle="collapse" href="#pi"><span class="glyphicon glyphicon-file"></span> Purchase Instruction</a>
            <ul class="list-group panel-collapse collapse" id="pi">
                <li class="list-group-item"><a href="/app/home/input_customer">New PI</a></li>
                <li class="list-group-item"><a href="/app/home/customer">Data PI</a></li>
            </ul>
        </li>
        <li>
            <a data-toggle="collapse" href="#ppi"><span class="glyphicon glyphicon-file"></span> Payment Purchase Instruction</a>
            <ul class="list-group panel-collapse collapse" id="ppi">
                <li class="list-group-item"><a href="/app/home/input_customer">New PPI</a></li>
                <li class="list-group-item"><a href="/app/home/customer">Data PPI</a></li>
            </ul>
        </li>
        <li>
            <a data-toggle="collapse" href="#"><span class="glyphicon glyphicon-file"></span> Shipment</a>
            <ul class="list-group panel-collapse collapse" id="customer">
                <li class="list-group-item"><a href="/app/home/input_customer">New Customer</a></li>
                <li class="list-group-item"><a href="/app/home/customer">Data Customer</a></li>
            </ul>
        </li>
    </ul>
</div>
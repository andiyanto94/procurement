<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function index()
    {
        $data['title']='home';
        $data['page']='dashboard';
        $this->load->view('home',$data);
    }
    function po()
    {
        $data['title']='Purchase Order';
        $data['page']='/content/po/po';
        $this->load->view('home',$data);
    }
    function input_po()
    {
        $data['title']='Input Purchase Order';
        $data['page']='/content/po/new_po';
        $this->load->view('home',$data);
    }
    function pi()
    {
        $data['title']='Purchase Instruction';
        $data['page']='/content/pi/pi';
        $this->load->view('home',$data);
    }
    function ppi()
    {
        $data['title']='Payment Purchase Intruction';
        $data['page']='/content/ppi/ppi';
        $this->load->view('home',$data);
    }
    function deor()
    {
        $data['title']='Payment Purchase Intruction';
        $data['page']='/content/deor';
        $this->load->view('home',$data);
    }
    function input_customer()
    {
        $data['title']='Payment Purchase Intruction';
        $data['page']='/content/customer/input_customer';
        $this->load->view('home',$data);
    }
    function customer()
    {
        $data['title']='Data Customer';
        $data['page']='/content/customer/customer';
        $this->load->view('home',$data);
    }
    function vendor()
    {
        $data['title']='Data Vendor';
        $data['page']='/content/vendor/vendor';
        $this->load->view('home',$data);
    }
    function material()
    {
        $data['title']='Data Material';
        $data['page']='/content/material/material';
        $this->load->view('home',$data);
    }
        
}
